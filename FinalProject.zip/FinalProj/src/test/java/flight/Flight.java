package flight;

import org.testng.annotations.Test;
import org.testng.annotations.BeforeTest;

import java.io.FileInputStream;
import java.io.IOException;

import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;
import org.testng.annotations.AfterTest;

public class Flight
{
	WebDriver wb;
  @Test
  public void f() throws IOException
  {
	  FileInputStream fis=new FileInputStream("C:\\Users\\gauri\\Desktop\\inputdata.xlsx");
		XSSFWorkbook book=new XSSFWorkbook(fis);
		XSSFSheet sh=book.getSheet("flight");
		
		int size= sh.getLastRowNum();
		System.out.println("No. of records :"+size);
		for(int i=1; i<=size; i++)
		{
			String type=sh.getRow(i).getCell(0).toString();
			String passen=sh.getRow(i).getCell(1).toString();
			String DepartFrom=sh.getRow(i).getCell(2).toString();
			String Onmonth=sh.getRow(i).getCell(3).toString();
			String Ondate=sh.getRow(i).getCell(4).toString();
			String Arriving=sh.getRow(i).getCell(5).toString();
			String Returning=sh.getRow(i).getCell(6).toString();
			String ReturningDate=sh.getRow(i).getCell(7).toString();
			String ServiceClass=sh.getRow(i).getCell(8).toString();
			String Airline=sh.getRow(i).getCell(9).toString();
			System.out.println(type+" "+passen+" "+DepartFrom+" "+Onmonth+" "+Ondate+" "+Arriving+" "+Returning+" "+ReturningDate+" "+ServiceClass+" "+Airline);
			
			if(type.equalsIgnoreCase("roundtrip"))
			{
				wb.findElement(By.xpath("/html[1]/body[1]/div[2]/table[1]/tbody[1]/tr[1]/td[2]/table[1]/tbody[1]/tr[4]/td[1]/table[1]/tbody[1]/tr[1]/td[2]/table[1]/tbody[1]/tr[5]/td[1]/form[1]/table[1]/tbody[1]/tr[2]/td[2]/b[1]/font[1]/input[1]"));
			}
			if(type.equalsIgnoreCase("OneWay"))
			{
				wb.findElement(By.xpath("/html[1]/body[1]/div[2]/table[1]/tbody[1]/tr[1]/td[2]/table[1]/tbody[1]/tr[4]/td[1]/table[1]/tbody[1]/tr[1]/td[2]/table[1]/tbody[1]/tr[5]/td[1]/form[1]/table[1]/tbody[1]/tr[2]/td[2]/b[1]/font[1]/input[2]"));
			}
			Select passenger=new Select(wb.findElement(By.name("passCount")));
			passenger.selectByVisibleText(passen);
			Select Departing=new Select(wb.findElement(By.name("fromPort")));
			Departing.selectByVisibleText(DepartFrom);
			Select On=new Select(wb.findElement(By.name("fromMonth")));
			On.selectByVisibleText(Onmonth);
			Select date=new Select(wb.findElement(By.name("fromDay")));
			date.selectByVisibleText(Ondate);
			Select Arrive=new Select(wb.findElement(By.name("toPort")));
			Arrive.selectByVisibleText(Arriving);
			Select Return=new Select(wb.findElement(By.name("toMonth")));
			Return.selectByVisibleText(Returning);
			Select ReturnDate=new Select(wb.findElement(By.name("toDay")));
			ReturnDate.selectByVisibleText(ReturningDate);
			
			if(ServiceClass.equalsIgnoreCase("Economy class"))
			{
				wb.findElement(By.xpath("/html[1]/body[1]/div[2]/table[1]/tbody[1]/tr[1]/td[2]/table[1]/tbody[1]/tr[4]/td[1]/table[1]/tbody[1]/tr[1]/td[2]/table[1]/tbody[1]/tr[5]/td[1]/form[1]/table[1]/tbody[1]/tr[9]/td[2]/font[1]/input[1]")).click();
			}
			else if(ServiceClass.equalsIgnoreCase("Business class"))
			{
				wb.findElement(By.xpath("/html[1]/body[1]/div[2]/table[1]/tbody[1]/tr[1]/td[2]/table[1]/tbody[1]/tr[4]/td[1]/table[1]/tbody[1]/tr[1]/td[2]/table[1]/tbody[1]/tr[5]/td[1]/form[1]/table[1]/tbody[1]/tr[9]/td[2]/font[1]/font[1]/input[1]")).click();
			}
			else if(ServiceClass.equalsIgnoreCase("First class"))
			{
				wb.findElement(By.xpath("/html[1]/body[1]/div[2]/table[1]/tbody[1]/tr[1]/td[2]/table[1]/tbody[1]/tr[4]/td[1]/table[1]/tbody[1]/tr[1]/td[2]/table[1]/tbody[1]/tr[5]/td[1]/form[1]/table[1]/tbody[1]/tr[9]/td[2]/font[1]/font[1]/input[2]")).click();
			}
			Select a=new Select(wb.findElement(By.name("airline")));
			a.selectByVisibleText(Airline);
			
			if(DepartFrom==Arriving)
			{
				System.out.println("Failed");
			}
			else
			{
				System.out.println("Passed");
			}
		}
  }
  @BeforeTest
  public void beforeTest()
  {
	    System.setProperty("webdriver.chrome.driver","C:\\Users\\gauri\\Desktop\\Gauri\\New folder\\chromedriver.exe");
		wb=new ChromeDriver();
		wb.get("http://demo.guru99.com/test/newtours/index.php");
		wb.manage().window().maximize();
		wb.get("http://demo.guru99.com/test/newtours/reservation.php");
  }

  @AfterTest
  public void afterTest()
  {
	  wb.findElement(By.name("findFlights")).click();
	  wb.close();
  }
}