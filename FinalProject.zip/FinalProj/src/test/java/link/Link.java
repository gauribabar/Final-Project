package link;

import org.testng.annotations.Test;
import org.testng.annotations.BeforeTest;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterTest;

public class Link
{
	WebDriver wb;
  @Test
  public void f() throws InterruptedException
  {
	  wb.findElement(By.linkText("Hotels")).click();
	  Thread.sleep(2000);
	  String link=wb.getTitle();
	  if(link.contains("Under Construction")||wb.getCurrentUrl().equals("http://demo.guru99.com/test/newtours/support.php"))
	  {
		  System.out.println(wb.findElement(By.xpath("//tbody/tr[3]/td[1]/p[1]/font[1]/b[1]/font[1]")).getText());
	  }
	  
	  wb.findElement(By.linkText("Car Rentals")).click();
	  Thread.sleep(2000);
	  String Rentals=wb.getTitle();
	  if(Rentals.contains("Under Construction")||wb.getCurrentUrl().equals("http://demo.guru99.com/test/newtours/support.php"))
	  {
		  System.out.println(wb.findElement(By.xpath("//tbody/tr[3]/td[1]/p[1]/font[1]/b[1]/font[1]")).getText());
	  }
	  
	  wb.findElement(By.linkText("Cruises")).click();
	  Thread.sleep(2000);
	  String crui=wb.getTitle();
	  if(crui.contains("Welcome")||wb.getCurrentUrl().equals("http://demo.guru99.com/test/newtours/index.php"))
	  {
		  System.out.println("Page Not Found");
	  }
	  
	  wb.findElement(By.linkText("Destinations")).click();
	  Thread.sleep(2000);
	  String dest=wb.getTitle();
	  if(dest.contains("Under Construction")||wb.getCurrentUrl().equals("http://demo.guru99.com/test/newtours/support.php"))
	  {
		  System.out.println(wb.findElement(By.xpath("//tbody/tr[3]/td[1]/p[1]/font[1]/b[1]/font[1]")).getText());
	  }
	 
	  wb.findElement(By.linkText("Vacations")).click();
	  Thread.sleep(2000);
	  String vac=wb.getTitle();
	  if(vac.contains("Under Construction")||wb.getCurrentUrl().equals("http://demo.guru99.com/test/newtours/support.php"))
	  {
		  System.out.println(wb.findElement(By.xpath("//tbody/tr[3]/td[1]/p[1]/font[1]/b[1]/font[1]")).getText());
	  }
	  
	  wb.findElement(By.linkText("SUPPORT")).click();
	  Thread.sleep(2000);
	  String supp=wb.getTitle();
	  if(supp.contains("Under Construction")||wb.getCurrentUrl().equals("http://demo.guru99.com/test/newtours/support.php"))
	  {
		  System.out.println(wb.findElement(By.xpath("//tbody/tr[3]/td[1]/p[1]/font[1]/b[1]/font[1]")).getText());
	  }
	 
	  wb.findElement(By.linkText("CONTACT")).click();
	  Thread.sleep(2000);
	  String cont=wb.getTitle();
	  if(cont.contains("Under Construction")||wb.getCurrentUrl().equals("http://demo.guru99.com/test/newtours/support.php"))
	  {
		  System.out.println(wb.findElement(By.xpath("//tbody/tr[3]/td[1]/p[1]/font[1]/b[1]/font[1]")).getText());
	  }
  }
  @BeforeTest
  public void beforeTest()
  {
	  System.setProperty("webdriver.chrome.driver","C:\\Users\\gauri\\Desktop\\Gauri\\New folder\\chromedriver.exe");
	  wb=new ChromeDriver();
	  wb.get("http://demo.guru99.com/test/newtours/index.php");
	  wb.manage().window().maximize();
  }

  @AfterTest
  public void afterTest()
  {
	  wb.close();
  }
}