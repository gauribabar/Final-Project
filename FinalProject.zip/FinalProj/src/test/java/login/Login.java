package login;

import org.testng.annotations.Test;
import org.testng.annotations.BeforeTest;

import java.io.FileInputStream;
import java.io.IOException;

import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterTest;

public class Login
{
	WebDriver wb;
  @Test
  public void f() throws IOException
  {
	  	FileInputStream fis=new FileInputStream("C:\\Users\\gauri\\Desktop\\inputdata.xlsx");
		XSSFWorkbook book=new XSSFWorkbook(fis);
		XSSFSheet sh=book.getSheet("Sheet1");
		int size=sh.getLastRowNum();
		System.out.println("No. of records :"+size);
		for(int i=1; i<=size; i++)
		{
			String username=sh.getRow(i).getCell(0).toString();
			String password=sh.getRow(i).getCell(1).toString();
			wb.findElement(By.name("userName")).sendKeys(username);
			wb.findElement(By.name("password")).sendKeys(password);
			wb.findElement(By.name("submit")).click();
			System.out.println(username+" "+password);
			
			try
			{
				wb.findElement(By.linkText("SIGN-OFF")).click();
			}
			catch(Exception e)
			{
				System.out.println("Invalid Data");
			}
		}
  }
  @BeforeTest
  public void beforeTest()
  {
	  System.setProperty("webdriver.chrome.driver","C:\\Users\\gauri\\Desktop\\Gauri\\New folder\\chromedriver.exe");
	  wb=new ChromeDriver();
	  wb.get("http://demo.guru99.com/test/newtours/index.php");
	  wb.manage().window().maximize();
  }

  @AfterTest
  public void afterTest()
  {
	  wb.close();
  }
}