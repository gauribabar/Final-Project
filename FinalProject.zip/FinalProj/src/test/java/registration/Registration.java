package registration;

import org.testng.annotations.Test;
import org.testng.annotations.BeforeTest;

import java.io.FileInputStream;
import java.io.IOException;

import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;
import org.testng.annotations.AfterTest;

public class Registration
{
	static WebDriver wb;
	XSSFWorkbook book;
	XSSFSheet sh1;
	XSSFSheet sh2;
  
	public static void register(int i, XSSFSheet sh)throws IOException
	{
	  String fname=sh.getRow(i).getCell(0).toString();
	  String lname=sh.getRow(i).getCell(1).toString();
	  String phnno=sh.getRow(i).getCell(2).toString();
	  String email=sh.getRow(i).getCell(3).toString();
	  String add=sh.getRow(i).getCell(4).toString();
	  String city=sh.getRow(i).getCell(5).toString();
	  String state=sh.getRow(i).getCell(6).toString();
	  String postalcode=sh.getRow(i).getCell(7).toString();
	  String username=sh.getRow(i).getCell(8).toString();
	  String password=sh.getRow(i).getCell(9).toString();
	  String confirmpassword=sh.getRow(i).getCell(10).toString();
	  
	  wb.findElement(By.name("firstName")).sendKeys(fname);
	  wb.findElement(By.name("lastName")).sendKeys(lname);
	  wb.findElement(By.name("phone")).sendKeys(phnno);
	  wb.findElement(By.name("userName")).sendKeys(email);
	  wb.findElement(By.name("address1")).sendKeys(add);
	  wb.findElement(By.name("city")).sendKeys(city);
	  wb.findElement(By.name("state")).sendKeys(state);
	  wb.findElement(By.name("postalCode")).sendKeys(postalcode);
	  Select c=new Select(wb.findElement(By.name("country")));
	  c.selectByVisibleText("INDIA");
	  wb.findElement(By.name("email")).sendKeys(username);
	  wb.findElement(By.name("password")).sendKeys(password);
	  wb.findElement(By.name("confirmPassword")).sendKeys(confirmpassword);
	  wb.findElement(By.name("submit")).click();
	}
  @Test
  public static void read() throws IOException
  {
	  FileInputStream fis=new FileInputStream("C:\\Users\\gauri\\Desktop\\inputdata.xlsx");
	  XSSFWorkbook book=new XSSFWorkbook(fis);
	  XSSFSheet sh1=book.getSheet("regis");
	  XSSFSheet sh2=book.getSheet("regis1");
	  
	  int size=sh1.getLastRowNum();
	  System.out.println("No. of records: "+size);
	  
	  for(int i=1; i<size; i++)
	  {
		  Registration.register(i, sh1);
		  if(wb.getCurrentUrl().equals("http://demo.guru99.com/test/newtours/register_sucess.php"))
		  {
			  System.out.println("Test Case Passed");
			  wb.findElement(By.linkText("REGISTER")).click();
		  }
		  else
		  {
			  System.out.println("Test Case Failed");
			  wb.findElement(By.linkText("REGISTER")).click();
		  }
	  }
	  
	  int size2=sh2.getLastRowNum();
	  System.out.println("No. of records: "+size2);
	  
	  for(int i=1; i<size2; i++)
	  {
		  Registration.register(i, sh2);
		  if(wb.getCurrentUrl().equals("http://demo.guru99.com/test/newtours/register_sucess.php"))
		  {
			  System.out.println("Test Case Failed");
			  wb.findElement(By.linkText("REGISTER")).click();
		  }
		  else
		  {
			  System.out.println("Test Case Passed");
			  wb.findElement(By.linkText("REGISTER")).click();
		  }
	  }
  }
  
  @BeforeTest
  public void beforeTest()
  {
	  System.setProperty("webdriver.chrome.driver","C:\\Users\\gauri\\Desktop\\Gauri\\New folder\\chromedriver.exe");
	  wb=new ChromeDriver();
	  wb.get("http://demo.guru99.com/test/newtours/register.php");
	  wb.manage().window().maximize();
	  wb.findElement(By.linkText("REGISTER")).click();
  }

  @AfterTest
  public void afterTest()
  {
	  wb.close();
  }
}